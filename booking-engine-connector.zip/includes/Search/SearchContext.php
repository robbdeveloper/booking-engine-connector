<?php

declare(strict_types=1);

namespace BookingEngineConnector\Search;

/**
 * Search / quote context parsed from URL query parameters.
 *
 * All public query keys use the `bec_` prefix to avoid collisions with WordPress
 * and other plugins. Supported keys:
 *
 * - `bec_checkin` — check-in date (Y-m-d or site-accepted string)
 * - `bec_checkout` — check-out date
 * - `bec_adults` — adult count (positive integer)
 * - `bec_children` — child count (non-negative integer)
 */
final class SearchContext
{
	public const PARAM_CHECKIN = 'bec_checkin';

	public const PARAM_CHECKOUT = 'bec_checkout';

	public const PARAM_ADULTS = 'bec_adults';

	public const PARAM_CHILDREN = 'bec_children';

	private string $checkin = '';

	private string $checkout = '';

	private int $adults = 0;

	private int $children = 0;

	private function __construct()
	{
	}

	public static function fromRequest(): self
	{
		$ctx       = new self();
		$ctx->checkin  = isset($_GET[self::PARAM_CHECKIN])
			? sanitize_text_field(wp_unslash((string) $_GET[self::PARAM_CHECKIN]))
			: '';
		$ctx->checkout = isset($_GET[self::PARAM_CHECKOUT])
			? sanitize_text_field(wp_unslash((string) $_GET[self::PARAM_CHECKOUT]))
			: '';
		$ctx->adults   = isset($_GET[self::PARAM_ADULTS])
			? max(0, absint($_GET[self::PARAM_ADULTS]))
			: 0;
		$ctx->children = isset($_GET[self::PARAM_CHILDREN])
			? max(0, absint($_GET[self::PARAM_CHILDREN]))
			: 0;

		return $ctx;
	}

	/**
	 * @return array<string, string|int> Non-empty values suitable for URL query building.
	 */
	public function toQueryArgs(): array
	{
		$args = [];

		if ($this->checkin !== '') {
			$args[self::PARAM_CHECKIN] = $this->checkin;
		}
		if ($this->checkout !== '') {
			$args[self::PARAM_CHECKOUT] = $this->checkout;
		}
		if ($this->adults > 0) {
			$args[self::PARAM_ADULTS] = $this->adults;
		}
		if ($this->children > 0) {
			$args[self::PARAM_CHILDREN] = $this->children;
		}

		return $args;
	}

	/**
	 * Whether the minimum fields needed to request a quote are present.
	 *
	 * Requires non-empty check-in and check-out and at least one adult.
	 */
	public function isComplete(): bool
	{
		return $this->checkin !== ''
			&& $this->checkout !== ''
			&& $this->adults > 0;
	}

	public function getCheckin(): string
	{
		return $this->checkin;
	}

	public function getCheckout(): string
	{
		return $this->checkout;
	}

	public function getAdults(): int
	{
		return $this->adults;
	}

	public function getChildren(): int
	{
		return $this->children;
	}

	/**
	 * Payload for {@see ProviderInterface::getQuoteForUnit()}.
	 *
	 * @return array{checkin: string, checkout: string, adults: int, children: int}
	 */
	public function toProviderSearchContext(): array
	{
		return [
			'checkin'  => $this->checkin,
			'checkout' => $this->checkout,
			'adults'   => $this->adults,
			'children' => $this->children,
		];
	}
}
