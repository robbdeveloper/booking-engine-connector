<?php

declare(strict_types=1);

namespace BookingEngineConnector\Providers\Contracts;

use BookingEngineConnector\Providers\Auth\CredentialField;

/**
 * Booking provider abstraction (Kross, future engines).
 */
interface ProviderInterface
{
	public function getSlug(): string;

	/**
	 * Declarative credential field definitions for admin UI and validation.
	 *
	 * @return list<CredentialField>|array<int, array<string, mixed>>
	 */
	public function getCredentialSchema(): array;

	public function validateCredentials(): bool;

	/**
	 * Fetch remote inventory metadata for mapping/sync (not implemented in stub providers).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function fetchRemoteUnits(): array;

	/**
	 * Price/availability quote for one remote unit and a search context.
	 *
	 * @param array<string, mixed> $searchContext Dates, guests, and provider-specific params.
	 */
	public function getQuoteForUnit(string $remoteUnitId, array $searchContext): mixed;

	/**
	 * External checkout / booking URL for this unit and stay, or null if not supported.
	 *
	 * @param array<string, mixed> $searchContext Same shape as for quotes (checkin, checkout, adults, children).
	 * @return array{url: string, label?: string}|null
	 */
	public function buildCheckoutUrl(string $remoteUnitId, array $searchContext): ?array;
}
