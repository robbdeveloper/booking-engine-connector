<?php

declare(strict_types=1);

namespace BookingEngineConnector\Shortcodes;

use BookingEngineConnector\Checkout\CheckoutUrlService;
use BookingEngineConnector\Fallback\FallbackRenderer;
use BookingEngineConnector\PostTypes\UnitPostType;
use BookingEngineConnector\Search\QuoteService;
use BookingEngineConnector\Search\SearchContext;
use BookingEngineConnector\Search\SearchForm;

/**
 * Public shortcodes (TASK-SHO-001).
 */
final class ShortcodeRegistry
{
	public static function register(): void
	{
		\add_shortcode('bec_version', [self::class, 'renderVersion']);
		\add_shortcode('bec_search', [self::class, 'renderSearch']);
		\add_shortcode('bec_dates', [self::class, 'renderDates']);
		\add_shortcode('bec_checkout', [self::class, 'renderCheckout']);
		\add_shortcode('bec_quote', [self::class, 'renderQuote']);
		\add_shortcode('bec_fallback', [self::class, 'renderFallback']);
	}

	public static function renderVersion(): string
	{
		return \esc_html((string) \BEC_VERSION);
	}

	public static function renderSearch($atts = []): string
	{
		$a = \shortcode_atts(
			[
				'context' => 'shortcode',
				'form_id' => 'bec-search-form-sc',
			],
			\is_array($atts) ? $atts : [],
			'bec_search'
		);

		\ob_start();
		SearchForm::render(
			[
				'context' => (string) $a['context'],
				'form_id' => (string) $a['form_id'],
			]
		);

		return (string) \ob_get_clean();
	}

	public static function renderDates(): string
	{
		$ctx = SearchContext::fromRequest();
		if (! $ctx->isComplete()) {
			return '';
		}

		$fmt = (string) \apply_filters('bec_shortcode_dates_format', '', $ctx);
		if ($fmt !== '') {
			return '<p class="bec-shortcode-dates">' . \esc_html($fmt) . '</p>';
		}

		$out = \sprintf(
			/* translators: 1: check-in date, 2: check-out date */
			\esc_html__('%1$s → %2$s', 'booking-engine-connector'),
			\esc_html($ctx->getCheckin()),
			\esc_html($ctx->getCheckout())
		);

		return '<p class="bec-shortcode-dates">' . $out . '</p>';
	}

	public static function renderCheckout($atts = []): string
	{
		$a = \shortcode_atts(
			['unit_id' => '0'],
			\is_array($atts) ? $atts : [],
			'bec_checkout'
		);

		$postId = (int) $a['unit_id'];
		if ($postId < 1) {
			$postId = (int) \get_the_ID();
		}
		if ($postId < 1 || \get_post_type($postId) !== UnitPostType::getSlug()) {
			return '';
		}

		$ctx = SearchContext::fromRequest();
		if (! $ctx->isComplete()) {
			return '';
		}

		$urlData = CheckoutUrlService::buildForPost($postId, $ctx);
		if ($urlData === null || ! isset($urlData['url']) || (string) $urlData['url'] === '') {
			return '';
		}

		$label = isset($urlData['label']) && (string) $urlData['label'] !== ''
			? (string) $urlData['label']
			: \__('Book now', 'booking-engine-connector');

		return '<p class="bec-shortcode-checkout"><a class="bec-checkout-cta" href="' . \esc_url((string) $urlData['url']) . '">' . \esc_html($label) . '</a></p>';
	}

	public static function renderQuote($atts = []): string
	{
		$a = \shortcode_atts(
			['unit_id' => '0'],
			\is_array($atts) ? $atts : [],
			'bec_quote'
		);

		$postId = (int) $a['unit_id'];
		if ($postId < 1) {
			$postId = (int) \get_the_ID();
		}
		if ($postId < 1 || \get_post_type($postId) !== UnitPostType::getSlug()) {
			return '';
		}

		$ctx = SearchContext::fromRequest();
		if (! $ctx->isComplete()) {
			return '';
		}

		$quote = QuoteService::getQuote($postId, $ctx);
		if ($quote instanceof \WP_Error) {
			return '';
		}
		if (! \is_array($quote)) {
			return '';
		}

		$available = ! empty($quote['available']);
		$text      = $available
			? \__('Available for your dates.', 'booking-engine-connector')
			: \__('No availability for these dates.', 'booking-engine-connector');

		$text = (string) \apply_filters('bec_shortcode_quote_text', $text, $quote, $postId, $ctx);

		return '<p class="bec-shortcode-quote">' . \esc_html($text) . '</p>';
	}

	public static function renderFallback(): string
	{
		return FallbackRenderer::render();
	}
}
