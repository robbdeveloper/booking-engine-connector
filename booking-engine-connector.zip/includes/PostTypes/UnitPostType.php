<?php

declare(strict_types=1);

namespace BookingEngineConnector\PostTypes;

use DateTimeImmutable;
use DateTimeInterface;
use WP_Query;

/**
 * Registers the Unit custom post type and related meta, REST fields, and admin list UI.
 */
final class UnitPostType
{
	private static string $slug = 'bec_unit';

	public static function register(): void
	{
		add_action('init', [self::class, 'onInit'], 5);
	}

	public static function getSlug(): string
	{
		return self::$slug;
	}

	public static function onInit(): void
	{
		self::$slug = (string) apply_filters('bec_unit_post_type_slug', 'bec_unit');

		register_post_type(
			self::$slug,
			[
				'labels'              => self::labels(),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true,
				'menu_icon'           => 'dashicons-building',
				'menu_position'       => 6,
				'supports'            => ['title', 'editor', 'thumbnail'],
				'has_archive'         => (bool) apply_filters('bec_unit_has_archive', false),
				'rewrite'             => ['slug' => self::$slug],
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
			]
		);

		self::registerMeta();
		self::registerAdminListHooks();
	}

	/**
	 * @return array<string, string>
	 */
	private static function labels(): array
	{
		return [
			'name'                  => _x('Units', 'post type general name', 'booking-engine-connector'),
			'singular_name'         => _x('Unit', 'post type singular name', 'booking-engine-connector'),
			'menu_name'             => _x('Units', 'Admin Menu text', 'booking-engine-connector'),
			'name_admin_bar'        => _x('Unit', 'Add New on Toolbar', 'booking-engine-connector'),
			'add_new'               => __('Add New', 'booking-engine-connector'),
			'add_new_item'          => __('Add New Unit', 'booking-engine-connector'),
			'new_item'              => __('New Unit', 'booking-engine-connector'),
			'edit_item'             => __('Edit Unit', 'booking-engine-connector'),
			'view_item'             => __('View Unit', 'booking-engine-connector'),
			'all_items'             => __('Units', 'booking-engine-connector'),
			'search_items'          => __('Search Units', 'booking-engine-connector'),
			'parent_item_colon'     => __('Parent Units:', 'booking-engine-connector'),
			'not_found'             => __('No units found.', 'booking-engine-connector'),
			'not_found_in_trash'    => __('No units found in Trash.', 'booking-engine-connector'),
			'featured_image'        => _x('Unit featured image', 'Overrides “Featured Image”', 'booking-engine-connector'),
			'set_featured_image'    => _x('Set unit image', 'Overrides “Set featured image”', 'booking-engine-connector'),
			'remove_featured_image' => _x('Remove unit image', 'Overrides “Remove featured image”', 'booking-engine-connector'),
			'use_featured_image'    => _x('Use as unit image', 'Overrides “Use as featured image”', 'booking-engine-connector'),
			'archives'              => _x('Unit archives', 'Post type archive label in nav menus', 'booking-engine-connector'),
			'insert_into_item'      => _x('Insert into unit', 'Overrides “Insert into post”', 'booking-engine-connector'),
			'uploaded_to_this_item' => _x('Uploaded to this unit', 'Overrides “Uploaded to this post”', 'booking-engine-connector'),
			'filter_items_list'     => _x('Filter units list', 'Screen reader text for filter links', 'booking-engine-connector'),
			'items_list_navigation' => _x('Units list navigation', 'Screen reader text for pagination', 'booking-engine-connector'),
			'items_list'            => _x('Units list', 'Screen reader text for items list', 'booking-engine-connector'),
		];
	}

	private static function registerMeta(): void
	{
		$auth = static function ($allowed, $meta_key, $post_id) {
			return current_user_can('edit_post', (int) $post_id);
		};

		register_post_meta(
			self::$slug,
			'bec_external_id',
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $auth,
				'default'           => '',
				'schema'            => [
					'type' => 'string',
				],
			]
		);

		register_post_meta(
			self::$slug,
			'bec_provider_slug',
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $auth,
				'default'           => '',
				'schema'            => [
					'type' => 'string',
				],
			]
		);

		register_post_meta(
			self::$slug,
			'bec_last_sync_at',
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => [self::class, 'sanitizeLastSyncAt'],
				'auth_callback'     => $auth,
				'default'           => '',
				'schema'            => [
					'type'        => 'string',
					'description' => 'ISO 8601 datetime or empty.',
				],
			]
		);

		register_post_meta(
			self::$slug,
			'bec_sync_enabled',
			[
				'type'              => 'boolean',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => [self::class, 'sanitizeSyncEnabled'],
				'auth_callback'     => $auth,
				'default'           => true,
				'schema'            => [
					'type' => 'boolean',
				],
			]
		);
	}

	/**
	 * @param mixed $value
	 */
	public static function sanitizeLastSyncAt($value): string
	{
		if ($value === null || $value === '') {
			return '';
		}

		if (! is_string($value)) {
			return '';
		}

		$value = trim($value);
		if ($value === '') {
			return '';
		}

		try {
			return (new DateTimeImmutable($value))->format(DateTimeInterface::ATOM);
		} catch (\Exception $e) {
			return '';
		}
	}

	/**
	 * @param mixed $value
	 */
	public static function sanitizeSyncEnabled($value): bool
	{
		if (is_bool($value)) {
			return $value;
		}

		if (is_string($value)) {
			return in_array(strtolower($value), ['1', 'true', 'yes', 'on'], true);
		}

		if (is_int($value) || is_float($value)) {
			return (int) $value !== 0;
		}

		return (bool) $value;
	}

	private static function registerAdminListHooks(): void
	{
		add_filter('manage_' . self::$slug . '_posts_columns', [self::class, 'filterPostColumns']);
		add_action('manage_' . self::$slug . '_posts_custom_column', [self::class, 'renderPostColumn'], 10, 2);
		add_filter('manage_edit-' . self::$slug . '_sortable_columns', [self::class, 'filterSortableColumns']);
		add_action('pre_get_posts', [self::class, 'sortAdminListByMeta']);
	}

	/**
	 * @param array<string, string> $columns
	 * @return array<string, string>
	 */
	public static function filterPostColumns(array $columns): array
	{
		$out = [];
		foreach ($columns as $key => $label) {
			$out[ $key ] = $label;
			if ($key === 'title') {
				$out['bec_external_id']   = __('External ID', 'booking-engine-connector');
				$out['bec_provider_slug'] = __('Provider', 'booking-engine-connector');
				$out['bec_last_sync_at']  = __('Last sync', 'booking-engine-connector');
			}
		}

		return $out;
	}

	public static function renderPostColumn(string $column, int $post_id): void
	{
		switch ($column) {
			case 'bec_external_id':
				echo esc_html((string) get_post_meta($post_id, 'bec_external_id', true));
				break;
			case 'bec_provider_slug':
				echo esc_html((string) get_post_meta($post_id, 'bec_provider_slug', true));
				break;
			case 'bec_last_sync_at':
				echo esc_html((string) get_post_meta($post_id, 'bec_last_sync_at', true));
				break;
		}
	}

	/**
	 * @param array<string, string> $columns
	 * @return array<string, string>
	 */
	public static function filterSortableColumns(array $columns): array
	{
		$columns['bec_external_id']   = 'bec_external_id';
		$columns['bec_provider_slug'] = 'bec_provider_slug';
		$columns['bec_last_sync_at']  = 'bec_last_sync_at';

		return $columns;
	}

	public static function sortAdminListByMeta(WP_Query $query): void
	{
		if (! is_admin() || ! $query->is_main_query()) {
			return;
		}

		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		if ($screen === null || $screen->id !== 'edit-' . self::$slug) {
			return;
		}

		$orderby = $query->get('orderby');
		if (! is_string($orderby)) {
			return;
		}

		if (! in_array($orderby, ['bec_external_id', 'bec_provider_slug', 'bec_last_sync_at'], true)) {
			return;
		}

		$query->set('meta_key', $orderby);
		$query->set('orderby', 'meta_value');
	}
}
