<?php

declare(strict_types=1);

namespace BookingEngineConnector\Checkout;

use BookingEngineConnector\Providers\ProviderRegistry;
use BookingEngineConnector\Search\SearchContext;
use BookingEngineConnector\Search\SearchValidator;

/**
 * Resolves checkout URL for a unit post via the active provider (TASK-CHK-001).
 */
final class CheckoutUrlService
{
	/**
	 * @return array{url: string, label?: string}|null
	 */
	public static function buildForPost(int $postId, SearchContext $ctx): ?array
	{
		if (! $ctx->isComplete()) {
			return null;
		}

		$validation = SearchValidator::validate($ctx);
		if ($validation instanceof \WP_Error) {
			return null;
		}

		$externalId = (string) \get_post_meta($postId, 'bec_external_id', true);
		if ($externalId === '') {
			return null;
		}

		$stored = (string) \get_post_meta($postId, 'bec_provider_slug', true);
		$slug   = $stored !== '' ? $stored : ProviderRegistry::getActiveSlug();
		$provider = ProviderRegistry::getProvider($slug);

		$raw = $provider->buildCheckoutUrl($externalId, $ctx->toProviderSearchContext());

		/** @var array{url: string, label?: string}|null $raw */
		return \apply_filters('bec_checkout_url', $raw, $postId, $ctx);
	}
}
