# Changelog

## 0.1.6 — 2026-03-20

- **Wave 6 (CHK / FB / UI / SHO)**: `CheckoutUrlService`, `BookingCtaRenderer`, `PublicContentBlocks` (append CTA or fallback after unit content when GET search is complete), `PublicAssets` + `assets/public.css`. `ProviderInterface::buildCheckoutUrl()` + `KrossProvider` (base URL option + filters). `FallbackService` / `FallbackRenderer`, admin **Checkout & fallback** (`bec_kross_checkout_base_url`, modes, triggers by `ProviderErrorCategory`, empty-quote trigger). Shortcodes: `bec_search`, `bec_dates`, `bec_checkout`, `bec_quote`, `bec_fallback`. Uninstall options extended.

## 0.1.5 — 2026-03-20

- **SEA-002 / SEA-003**: `SearchForm` + `SearchValidator` (dates, min/max nights via `bec_search_min_nights` / `bec_search_max_nights`); `SearchTemplateHooks` — `bec_before_search_form` / `bec_after_search_form`, `bec_before_unit_archive_loop` / `bec_after_unit_archive_loop`, optional `bec_auto_append_search_form_on_single_unit` (default true); `QuoteService::getQuote()` with `bec_quote_cache_ttl` and filters `bec_quote_search_context`, `bec_quote_result`, `bec_quote_cached_result`, `bec_quote_provider_error`. Template helpers `bec_render_search_form()`, `bec_get_unit_quote()`. CPT: `has_archive` via filter `bec_unit_has_archive`.

## 0.1.4 — 2026-03-20

- **SYNC (E3)**: `SyncService` (full + single post), `SyncLock`, `SyncCron` (WP-Cron `bec_run_scheduled_sync`, custom interval), admin **Sync** page (schedule + run now), row action & bulk “Sync with provider”, hooks `bec_before_unit_sync` / `bec_after_unit_sync`, filters for remote row and post data. `docs/SYNC.md`.

## 0.1.3 — 2026-03-20

- **PROV-003 (Kross v4)**: `KrossAuthenticator` aligned to GET `…/auth/get-token` + JSON body (`data.auth_token`); username/password credentials; `KrossApiClient` envelope (`auth_token` + `data`); `KrossProvider::fetchRemoteUnits()` → `get-room-types`; `getQuoteForUnit()` → `calendar/book`; `KrossResponseParser` for nested/JSON-in-string values.
- Docs: `docs/KROSS-API.md` mapping table updated.

## 0.1.2 — 2026-03-20

- **AUTH-003**: Connection admin page — provider select (`bec_registered_providers`), dynamic credential fields, save + **Verify connection**; filter `bec_test_connection` for custom providers (`WP_Error` or success string).
- **KrossAuthenticator**: shared `exchangeToken()` + `probeTokenExchange()` (test does not invalidate cached token on failure).

## 0.1.1 — 2026-03-20

- **HTTP-002**: `HttpClient` accepts optional `AuthenticatorInterface`; adds `Authorization: Bearer` when not skipped; at most **one** 401/403 invalidate + retry per logical request; internal args `bec_skip_auth`, `bec_log_profile`, `bec_provider_slug`, `bec_unit_id` (stripped before `wp_remote_request`).
- **LOG-002 / LOG-003 (minimal)**: `ApiLogRepository` persists business calls; auth/token calls omitted unless filter `bec_log_auth_requests` is true; admin **API Log** page with provider + status filters.

## 0.1.0 — 2026-03-20

- Scaffold plugin bootstrap, PSR-4 autoload, admin menu shell.
- CPT `bec_unit` with `bec_*` meta and admin columns.
- Search context helper (`bec_*` GET parameters).
- HTTP client with 429 backoff + correlation id.
- Provider contracts, Kross authenticator/provider stubs, provider registry.
- DB migration for `bec_api_log` table; uninstall policy documented.
